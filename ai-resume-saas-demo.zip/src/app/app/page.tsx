import Generator from '@/components/Generator';
export default function AppPage(){ return <Generator/> }